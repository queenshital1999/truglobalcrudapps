package com.truglobal.controller;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.truglobal.exception.EmployeeNotFoundException;
import com.truglobal.model.Employee;
import com.truglobal.service.EmpService;

@SpringBootTest
@AutoConfigureMockMvc
public class TestCaseForController {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private EmpService service;

	@Test
	public void testGetAllData() throws Exception {

		List<Employee> employeeList = Arrays.asList(new Employee(1, "nisha", "deshmukh", 23, "N@gmail.com"),
				new Employee(2, "nitin", "Chavan", 23, "Nit@gmail.com"));
		when(service.getallData()).thenReturn(employeeList);
		mockMvc.perform(get("/employees").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isAccepted())
				.andExpect(content().json(
						"[{\"id\":1,\"firstName\":\"nisha\",\"lastName\":\"deshmukh\",\"age\":23,\"email\":\"N@gmail.com\"},{\"id\":2,\"firstName\":\"nitin\",\"lastName\":\"Chavan\",\"age\":23,\"email\":\"Nit@gmail.com\"}]"));

	}

	@Test
	public void testInsertDataValidEmployee() throws Exception {

		Employee employeeToInsert = new Employee(1, "shital", "suryawanshi", 30, "shital@example.com");

		when(service.save(employeeToInsert)).thenReturn(employeeToInsert);

		mockMvc.perform(post("/employees/save").contentType(MediaType.APPLICATION_JSON).content(
				"{\"id\":1,\"firstName\":\"shital\",\"lastName\":\"suryawanshi\",\"age\":23,\"email\":\"shital@example.com\"}"))
				.andExpect(status().isCreated()) // Ensure the response status is 201 CREATED
				.andExpect(content().json(
						"{\"id\":1,\"firstName\":\"Shraddha\",\"lastName\":\"deshmukh\",\"age\":27,\"email\":\"shraddha@example.com\"}"));
	}

	@Test
	public void testGetById() throws Exception {
		Employee employee = new Employee(1, "shital", "suryawanshi", 23, "S@gmail.com");
		when(service.getById(1)).thenReturn(employee);
		mockMvc.perform(get("/1").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
				.andExpect(content().json(
						"{\"id\":1,\"firstName\":\"nisha\",\"lastName\":\"deshmukh\",\"age\":23,\"email\":\"N@gmail.com\"}"));
	}

	@Test
	public void testDeletedNotFound() throws Exception {
		doThrow(new EmployeeNotFoundException("Employee not found")).when(service).deleted(1);
		mockMvc.perform(delete("/1").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isNotFound());
	}

}
