package com.truglobal.service;

import java.util.List;

import com.truglobal.exception.EmployeeNotFoundException;
import com.truglobal.model.Employee;

public interface EmpService {

	Employee save(Employee e);

	Employee getById(int id) throws EmployeeNotFoundException;

	List<Employee> getallData();

	String deleted(int id) throws EmployeeNotFoundException;

	Employee udateData(Employee e, int id);

}
