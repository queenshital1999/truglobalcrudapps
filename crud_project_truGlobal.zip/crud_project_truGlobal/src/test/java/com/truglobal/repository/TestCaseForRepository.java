package com.truglobal.repository;

public class TestCaseForRepository {

}
