package com.truglobal.service;

import java.util.List;

import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.truglobal.exception.EmployeeNotFoundException;
import com.truglobal.model.Employee;
import com.truglobal.repository.EmpIRepository;

@Service
public class EmpService1 implements EmpService {
	@Autowired
	private EmpIRepository repo;

	@Override
	public Employee save(Employee e) {

		return repo.save(e);
	}

	@Override
	public Employee getById(int id) throws EmployeeNotFoundException {
		if (repo.findById(id).isPresent()) {

			return repo.findById(id).get();

		}
		throw new EmployeeNotFoundException("enter valid number");
	}

	@Override
	public List<Employee> getallData() {

		return repo.findAll();
	}

	@Override
	public String deleted(int id) throws EmployeeNotFoundException {
		if (repo.findById(id).isPresent()) {

			repo.deleteById(id);
			return "deleted";
		}
		throw new EmployeeNotFoundException("enter valid id");
	}

	@Override

	public Employee udateData(Employee e, int id) {
//		if (repo.findById(id).isPresent()) {
//			Employee e1 = repo.findById(id).get();
//
//			if (e.getFirstName() != null) {
//				e1.setFirstName(e.getFirstName());
//			}
//			if (e.getFirstName() != null) {
//				e1.setFirstName(e.getFirstName());
//			}
//			if (e.getAge() != 0) {
//				e1.setAge(id);
//			}
//			if (e.getEmail() != null) {
//				e1.setEmail(e.getEmail());
//
//			}
//			return repo.save(e1);
//		}
//		return null;
//	
		return repo.save(e);
	}
}
