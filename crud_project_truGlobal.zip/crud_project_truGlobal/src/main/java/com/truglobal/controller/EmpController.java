package com.truglobal.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.truglobal.exception.EmployeeNotFoundException;
import com.truglobal.model.Employee;
import com.truglobal.service.EmpService;

@RestController
@RequestMapping("/employees")
public class EmpController {
	@Autowired
	private EmpService service;

	@PostMapping("/save")
	public ResponseEntity<Employee> insertData(@Valid @RequestBody Employee e) {
		return new ResponseEntity<Employee>(service.save(e), HttpStatus.CREATED);

	}

	@GetMapping(value = "/{id}")
	public ResponseEntity<Employee> getById(@PathVariable int id) throws EmployeeNotFoundException {
		return new ResponseEntity<Employee>(service.getById(id), HttpStatus.OK);

	}

	@GetMapping
	public ResponseEntity<List<Employee>> getAllData() {
		return new ResponseEntity<List<Employee>>(service.getallData(), HttpStatus.ACCEPTED);
	}

	@DeleteMapping(value = "/{id}")
	public ResponseEntity<?> Deleted(@PathVariable int id) throws EmployeeNotFoundException {
		return new ResponseEntity<String>(service.deleted(id), HttpStatus.OK);
	}

	@PutMapping(value = "/{id}")
	public ResponseEntity<Employee> update(@RequestBody Employee e, @PathVariable int id) {

		return new ResponseEntity<Employee>(service.udateData(e, id), HttpStatus.OK);

	}
}
