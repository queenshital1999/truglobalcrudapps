package com.truglobal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class crud_project_trugloble {

	public static void main(String[] args) {
		SpringApplication.run(crud_project_trugloble.class, args);
		System.out.println("start");
	}

}
