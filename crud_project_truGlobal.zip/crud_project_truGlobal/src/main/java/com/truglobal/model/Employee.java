package com.truglobal.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Entity
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private int id;

	@NotEmpty
	@Size(min = 2, message = "Employee firstname should have at least 2 charaters")
	private String firstName;

	@Column(name = "lastname")
	@NotEmpty
	@Size(min = 5, message = "Employee lastname should have at least 5 charaters")
	private String lastName;

	@Min(18)
	@Max(60)
	private int age;

	@NotEmpty
	@Email
	private String email;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", age=" + age
				+ ", email=" + email + "]";
	}

	public Employee(int id,
			@NotEmpty @Size(min = 2, message = "Employee firstname should have at least 2 charaters") String firstName,
			@NotEmpty @Size(min = 5, message = "Employee lastname should have at least 5 charaters") String lastName,
			@Min(18) @Max(60) int age, @NotEmpty @Email String email) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.email = email;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
}